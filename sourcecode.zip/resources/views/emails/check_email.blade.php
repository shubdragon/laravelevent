<h3>This is a test email sent from the admin panel to ensure the proper configuration.</h3>
